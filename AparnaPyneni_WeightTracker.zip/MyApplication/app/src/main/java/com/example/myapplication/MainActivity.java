package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    WeightTrackerDB myDB;
    EditText editUName, editUPWD;
    Button btnLogin, btnAdd;
    private String luser = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDB = new WeightTrackerDB(this);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        editUName = (EditText)findViewById(R.id.editUsername);
        editUPWD = (EditText)findViewById(R.id.editPwd);
        btnLogin = (Button)findViewById(R.id.btnLogin);
        btnAdd = (Button)findViewById(R.id.btnAdd);
        Login();
        AddUser();

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void logout() {
        //FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
    public void AddUser(){
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDB.insertUser(editUName.getText().toString(),editUPWD.getText().toString());
                if(isInserted)
                    Toast.makeText(MainActivity.this,"New user is created successfully",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this,"New user creation is not successful",Toast.LENGTH_LONG).show();
            }
        });
    }
    public void Login(){
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"on click",Toast.LENGTH_LONG).show();
                boolean match = myDB.verify(editUName.getText().toString(),editUPWD.getText().toString());
                //Toast.makeText(MainActivity.this,match,Toast.LENGTH_LONG).show();
                if(match) {
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_LONG).show();
                    // Start QuestionActivity, indicating what subject was clicked
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("user", editUName.getText().toString());
                    //intent.putExtra(HomeActivity.EXTRA_SUBJECT, mSubject.getText());
                    startActivity(intent);
                }
                else
                    Toast.makeText(MainActivity.this,"Username/password is wrong",Toast.LENGTH_LONG).show();

            }
        });
    }
}