package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    WeightTrackerDB myDB;
    Button btnNotify, btnAddModify, btnDelete1, btnDelete2, btnDelete3, btnDelete4, btnDelete5;
    EditText editDate, editWeight;
    TextView txtDate1, txtDate2, txtDate3, txtDate4, txtDate5,txtWeight1,txtWeight2, txtWeight3, txtWeight4, txtWeight5;
    String lusr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        myDB = new WeightTrackerDB(this);
        btnNotify = (Button)findViewById(R.id.btnNotify);
        btnAddModify = (Button)findViewById(R.id.btnAddModify);
        editDate = (EditText)findViewById(R.id.editDate);
        editWeight = (EditText)findViewById(R.id.editWeight);

        txtDate1=(TextView)findViewById(R.id.txtDate1);
        txtWeight1=(TextView)findViewById(R.id.txtWeight1);
        btnDelete1=(Button)findViewById(R.id.btnDelete1);

        txtDate2=(TextView)findViewById(R.id.txtDate2);
        txtWeight2=(TextView)findViewById(R.id.txtWeight2);
        btnDelete2=(Button)findViewById(R.id.btnDelete2);

        txtDate3=(TextView)findViewById(R.id.txtDate3);
        txtWeight3=(TextView)findViewById(R.id.txtWeight3);
        btnDelete3=(Button)findViewById(R.id.btnDelete3);

        txtDate4=(TextView)findViewById(R.id.txtDate4);
        txtWeight4=(TextView)findViewById(R.id.txtWeight4);
        btnDelete4=(Button)findViewById(R.id.btnDelete4);

        txtDate5=(TextView)findViewById(R.id.txtDate5);
        txtWeight5=(TextView)findViewById(R.id.txtWeight5);
        btnDelete5=(Button)findViewById(R.id.btnDelete5);

        Intent intent=getIntent();
        lusr= intent.getStringExtra("user");

    //Login();
        AddModify(lusr);
        History(lusr);
        Delete(lusr);
        delete5(lusr);
        Notify();
    }
    public void Notify() {
        btnNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start QuestionActivity, indicating what subject was clicked
                Intent intent = new Intent(HomeActivity.this, NotificationActivity.class);
                //intent.putExtra(HomeActivity.EXTRA_SUBJECT, mSubject.getText());
                intent.putExtra("user",lusr);
                startActivity(intent);
            }
        });
    }
    public void History(String user) {
        Cursor cur = myDB.dailyWeights(user);
        if (cur != null)// If Cursor is null then do nothing
        {
            if (cur.moveToFirst()) {
                txtDate1.setText(cur.getString(cur.getColumnIndex("Date")));
                txtWeight1.setText(cur.getString(cur.getColumnIndex("Daily_Weight")));
            }
            else{
                txtDate1.setText("date");
                txtWeight1.setText("weight");
            }
            if (cur.moveToNext()) {
                txtDate2.setText(cur.getString(cur.getColumnIndex("Date")));
                txtWeight2.setText(cur.getString(cur.getColumnIndex("Daily_Weight")));
            }
            else{
                txtDate2.setText("date");
                txtWeight2.setText("weight");
            }
            if (cur.moveToNext()) {
                txtDate3.setText(cur.getString(cur.getColumnIndex("Date")));
                txtWeight3.setText(cur.getString(cur.getColumnIndex("Daily_Weight")));
            }
            else{
                txtDate3.setText("date");
                txtWeight3.setText("weight");
            }
            if (cur.moveToNext()) {
                txtDate4.setText(cur.getString(cur.getColumnIndex("Date")));
                txtWeight4.setText(cur.getString(cur.getColumnIndex("Daily_Weight")));
            }
            else{
                txtDate4.setText("date");
                txtWeight4.setText("weight");
            }
            if (cur.moveToNext()) {
                txtDate5.setText(cur.getString(cur.getColumnIndex("Date")));
                txtWeight5.setText(cur.getString(cur.getColumnIndex("Daily_Weight")));
            }
            else{
                txtDate5.setText("date");
                txtWeight5.setText("weight");
            }
        }
    }
    public void Delete(String user) {
        btnDelete1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(HomeActivity.this, "AddModify", Toast.LENGTH_LONG).show();
                boolean recordExists = myDB.deleteWeight(user, txtDate1.getText().toString(), txtWeight1.getText().toString());
                History(user);
            }
        });
        btnDelete2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(HomeActivity.this, "AddModify", Toast.LENGTH_LONG).show();
                boolean recordExists = myDB.deleteWeight(user, txtDate2.getText().toString(), txtWeight2.getText().toString());
                History(user);
            }
        });
        btnDelete3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(HomeActivity.this, "AddModify", Toast.LENGTH_LONG).show();
                boolean recordExists = myDB.deleteWeight(user, txtDate3.getText().toString(), txtWeight3.getText().toString());
                History(user);
            }
        });
        btnDelete4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(HomeActivity.this, "AddModify", Toast.LENGTH_LONG).show();
                boolean recordExists = myDB.deleteWeight(user, txtDate4.getText().toString(), txtWeight4.getText().toString());
                History(user);
            }
        });
    }
    public void delete5(String user){
        btnDelete5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(HomeActivity.this, "AddModify", Toast.LENGTH_LONG).show();
                boolean recordExists = myDB.deleteWeight(user, txtDate5.getText().toString(),txtWeight5.getText().toString());
                History(user);
            }
        });
    }
    public void AddModify(String user){
        btnAddModify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Toast.makeText(HomeActivity.this, "AddModify", Toast.LENGTH_LONG).show();
                boolean recordExists = myDB.verifyWeight(user, editDate.getText().toString());
                //Toast.makeText(HomeActivity.this, "record Inserted " + recordExists + " "+editDate.getText().toString(), Toast.LENGTH_LONG).show();
                if (recordExists) {
                    boolean isUpdated = myDB.updateWeight(user, editDate.getText().toString(), editWeight.getText().toString());
                    if (isUpdated)
                        Toast.makeText(HomeActivity.this, "Weight is updated", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(HomeActivity.this, "Weight Not updated", Toast.LENGTH_LONG).show();
                }
                else
                   {
                    boolean isInserted = myDB.insertWeight(user, editDate.getText().toString(), editWeight.getText().toString());
                    if (isInserted)
                        Toast.makeText(HomeActivity.this, "Daily Weight Inserted", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(HomeActivity.this, "Daily Weight Not inserted", Toast.LENGTH_LONG).show();
                }
                History(user);

            }
        });
    }

}