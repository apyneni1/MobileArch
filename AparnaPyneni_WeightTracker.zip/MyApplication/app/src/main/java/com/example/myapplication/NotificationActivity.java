package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.net.Uri;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.widget.RadioButton;
import android.widget.Toast;

public class NotificationActivity extends AppCompatActivity {
    Button btnOk,btnCancel;
    RadioButton rbYes, rbNo;
    String lusr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        btnOk = (Button)findViewById(R.id.btnOk);
        btnCancel = (Button)findViewById(R.id.btnCancel);
        rbYes=(RadioButton)findViewById(R.id.rbYes);
        rbNo=(RadioButton)findViewById(R.id.rbNo);
        Intent intent=getIntent();
        lusr= intent.getStringExtra("user");
        OkClick();
        CancelClick();
    }
    public void OkClick(){
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // try{
                    //Toast.makeText(NotificationActivity.this, "SMS1", Toast.LENGTH_SHORT).show();
                    //SmsManager smgr = SmsManager.getDefault();
                    if (rbYes.isChecked()) {
                        Toast.makeText(NotificationActivity.this, "SMS is sent successfully ", Toast.LENGTH_SHORT).show();
                    }
                     //Intent intent = new Intent(NotificationActivity.this, HomeActivity.class);
                    //intent.putExtra(HomeActivity.EXTRA_SUBJECT, mSubject.getText());
                    //startActivity(intent);
                    //smgr.sendTextMessage("5554",null,"Hello World",null,null);
                  //  Toast.makeText(NotificationActivity.this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
                //}
                //catch (Exception e){
                    //Toast.makeText(NotificationActivity.this, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
                //}
                // Start QuestionActivity, indicating what subject was clicked
                Intent intent = new Intent(NotificationActivity.this, HomeActivity.class);
                intent.putExtra("user",lusr);
                //intent.putExtra(HomeActivity.EXTRA_SUBJECT, mSubject.getText());
                startActivity(intent);
            }
        });
    }
    public void CancelClick(){
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start QuestionActivity, indicating what subject was clicked
                Intent intent = new Intent(NotificationActivity.this, HomeActivity.class);
                intent.putExtra("user",lusr);
                //intent.putExtra(HomeActivity.EXTRA_SUBJECT, mSubject.getText());
                startActivity(intent);
            }
        });
    }
}